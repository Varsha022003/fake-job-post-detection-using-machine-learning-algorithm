from flask import Flask, render_template, request, url_for
import pickle
import string
import re
import random
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer, ENGLISH_STOP_WORDS
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.base import TransformerMixin
from wordcloud import WordCloud, STOPWORDS
import spacy
from spacy.lang.en.stop_words import STOP_WORDS
from spacy.lang.en import English

#filename = 'rfc_model.pkl'
#classifier = pickle.load(open(filename, 'rb'))
#cv = pickle.load(open('cv-transform.pkl','rb'))
app = Flask(__name__)

df = pd.read_csv('fake_job_postings.csv')
columns = ['job_id', 'telecommuting', 'has_company_logo', 'has_questions', 'salary_range', 'employment_type']
for col in columns:
    del df[col]
df.fillna('',inplace=True)

exp = dict(df.required_experience.value_counts())
del exp['']

def split(location):
    l = location.split(',')
    return l[0]
df['country'] = df['location'].apply(split)

countr = dict(df.country.value_counts()[:14])
del countr['']


edu = dict(df.required_education.value_counts()[:7])
del edu['']


df['text'] = df['title']+' '+df['company_profile']+' '+df['description']+' '+df['requirements']+' '+df['benefits']
del df['title']
del df['location']
del df['department']
del df['company_profile']
del df['description']
del df['requirements']
del df['benefits']
del df['required_experience']
del df['required_education']
del df['industry']
del df['function']
del df['country']

fraudjobs_text = df[df.fraudulent==1].text
realjobs_text = df[df.fraudulent==0].text

STOPWORDS = spacy.lang.en.stop_words.STOP_WORDS

punctuations = string.punctuation

nlp = spacy.load("en_core_web_sm")
stop_words = spacy.lang.en.stop_words.STOP_WORDS

parser = English()

def spacy_tokenizer(sentence):
    mytokens = parser(sentence)
    
    #lemitize each token and converting to lowercase
    mytokens = [word.lemma_.lower().strip() if word.lemma_ != "-PRON-" else word.lower_ for word in mytokens]
    
    #Removing all the stopwords
    mytokens = [word for word in mytokens if word not in stop_words and word not in punctuations]
    
    #Returning processed words of token
    return mytokens


class predictors(TransformerMixin):
    def transform(self, X, **transform_params):
        
        return [clean_text(text) for text in X]
    
    def fit(self, X, y=None, **fit_params):
        return self
    
    def get_params(self, deep=True):
        return{}
    
#Cleaning the text
def clean_text(text):
    return text.strip().lower()

df['text'] = df['text'].apply(clean_text)

cv = TfidfVectorizer(max_features=100)
x = cv.fit_transform(df['text'])
df1 = pd.DataFrame(x.toarray(), columns=cv.get_feature_names_out())
df.drop(['text'], axis=1, inplace=True)
main_df = pd.concat([df1, df],axis=1)

Y = main_df.iloc[:,-1]
X = main_df.iloc[:,:-1]

X_train, X_test, y_train, y_test = train_test_split(X,Y,test_size=0.3)

from sklearn.svm import SVC, LinearSVC
svm = SVC(kernel = 'linear')
classifier=svm.fit(X_train,y_train)
y_pred = svm.predict(X_test)

@app.route("/", endpoint='func1')
def main_page():
    return render_template('home.html')

@app.route("/news_page", endpoint='func3')
def news():
    return render_template('news.html')

@app.route("/contact_page", endpoint='func4')
def contact():
    return render_template('contact.html')
    
@app.route("/predict", methods = ['POST', 'GET'], endpoint='func2')
def predict():
    if request.method == 'POST':
        n = request.form['news']
        data = [n]
        vect = cv.transform(data).toarray()
        my_prediction = classifier.predict(vect)
        return render_template('predicted.html', prediction = my_prediction)

if __name__ ==  "__main__":
    app.run(debug=True)